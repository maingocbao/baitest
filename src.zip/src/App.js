
import { useState } from "react";

export default function App() {
  const STATUSES = [
    { label: 'Tất cả', value: 2 },
    { label: 'Đang kinh doanh', value: 1 },
    { label: 'Ngừng kinh doanh', value: 0 },
  ];
  const DATA = [
    {
    
      BrandCode: 'SAMSUNG',
      CateProCode: 'DIENTHOAI',
      ProductCode: 'GALAXYS22ULTRA',
      ProductName: 'Galaxy S22 Ultra 5G 128GB',
      Price: 27000000,
      UPDc: 2000000,
      UPRateDc: 0,
      FlagPrice: 1,
      FlagActive: 0,
    },
    {
   
      BrandCode: 'SAMSUNG',
      CateProCode: 'DIENTHOAI',
      ProductCode: 'GALAXYZFLIP3',
      ProductName: 'Galaxy Z Flip3 5G 256GB',
      Price: 17000000,
      UPDc: 1700000,
      UPRateDc: 10,
      FlagPrice: 0,
      FlagActive: 1,
    },
    {

      BrandCode: 'IPHONE',
      CateProCode: 'DIENTHOAI',
      ProductCode: 'IPHONE13PROMAX',
      ProductName: 'iPhone 13 Pro Max 128GB',
      Price: 29000000,
      UPDc: 2900000,
      UPRateDc: 10,
      FlagPrice: 0,
      FlagActive: 1,
    },
    {

      BrandCode: 'IPHONE',
      CateProCode: 'DIENTHOAI',
      ProductCode: 'IPHONE13MINI',
      ProductName: 'iPhone 13 Mini 526GB',
      Price: 24000000,
      UPDc: 3000000,
      UPRateDc: 0,
      FlagPrice: 1,
      FlagActive: 0,
    },
    {

      BrandCode: 'OPPO',
      CateProCode: 'DIENTHOAI',
      ProductCode: 'OPPORENO7',
      ProductName: 'Oppo Reno7',
      Price: 9990000,
      UPDc: 1500000,
      UPRateDc: 0,
      FlagPrice: 1,
      FlagActive: 1,
    },
    {

      BrandCode: 'XIAOMI',
      CateProCode: 'DIENTHOAI',
      ProductCode: 'XIAOMIREDMINOTE11',
      ProductName: 'Xiaomi Redmi Note 11',
      Price: 4490000,
      UPDc: 449000,
      UPRateDc: 10,
      FlagPrice: 0,
      FlagActive: 1,
    },
  ];

  const [data, setData] = useState(DATA);
  const [newid, setNewid] = useState('');
  const [thuonghieu, setThuonghieu] = useState('');
  const [product, setProduct] = useState('');
  const [masp, setMasp] = useState('');
  const [tensp, setTensp] = useState('');
  const [gia, setGia] = useState('');
  const [edittingRow, setEdittingRow] = useState('')
  const [trangthai, setTranthai] = useState('');
  const [listDelete , setListDelete] = useState({});
  const onchangeThuonghieu = (e) => {
    setThuonghieu(e.currentTarget.value)

  }

  const onchangeNewID = (e) => {
    setNewid(e.currentTarget.value)
  }
  const onchangeSanpham = (e) => {
    setProduct(e.currentTarget.value)

  }
  const onchangeMasp = (e) => {
    setMasp(e.currentTarget.value)

  }
  const onchangeTensp = (e) => {
    setTensp(e.currentTarget.value)

  }
  const onchangeTrangthai = (e) => {
    setTranthai(e.currentTarget.value)

  }
  const onchangeGia = (e) => {
    setGia(e.currentTarget.value)

  }
  const handleSumbit = () => {
    let Datas = [...data]
    Datas.push({
   
      BrandCode: thuonghieu,
      CateProCode: product,
      ProductCode: masp,
      ProductName: tensp,
      Price: gia,
      FlagActive : trangthai
    })

    setData(Datas);
    setNewid('');
    setThuonghieu('');
    setProduct('');
    setMasp('');
    setTensp('');
    setGia('');
    setTranthai('');
    setEdittingRow('');

  }
  const handleChange = (e) => {
    const value = e.target.value;
    console.log( value)
    if (e.target.value === '2') {
      setData(DATA);
      return;
    } else{
      setData(DATA.filter((item) => item.FlagActive === Number(value)));
    }
    
  };
  const handleDelete =(e) =>{
    let value= e.target.value
    console.log(value)
    let datas = {
      ...listDelete
    }
    if (listDelete[value]){
      delete listDelete[value]
      datas ={
        ...listDelete
      }
    } else{
      datas ={
        ...listDelete,
        [value]: value
      }
    }
    // console.log(datas)
    setListDelete(datas);

   }
   const handleListDeltel = ()=>{
    let productCodeDeletes = Object.keys(listDelete);
    console.log(productCodeDeletes)
   let index = DATA.filter(item => !productCodeDeletes.includes(item.ProductCode));
   console.log(index)
   setData(index)

   }
  const handleChangeUpdate = () => {
let index = data.findIndex(item =>item.id === edittingRow)
let Datas = [...data];
Datas[index] ={
     
      BrandCode: thuonghieu,
      CateProCode: product,
      ProductCode: masp,
      ProductName: tensp,
      Price: gia,
      FlagActive : trangthai

}
setData(Datas);
setNewid('');
setThuonghieu('');
setProduct('');
setMasp('');
setTensp('');
setTranthai('');
setGia('');
  }
  const onPresDetelRow=(id) =>{
 let Newdata = [...data];
 let index =data.findIndex(item => item.id === id);
 Newdata.splice(index, 1);
 setData(Newdata);

  }
  const onPresEditingRow = (item , id) => {
    setNewid(id);
    setThuonghieu(item.BrandCode);
    console.log(setThuonghieu)
    setEdittingRow(id)
  } 

  return (
    <div>
      <select name="" id="" onChange={handleChange}>
        {STATUSES.map((item, index) => (

          <option key={index} value={item.value}>{item.label}</option>

        ))}
      </select>
      <button type="button"  onClick={()=>handleListDeltel()} >Tiến hành xóa nhiều</button>
      <table border={1}>
        <tr>
          <td>STT</td>
          <td>Action</td>
          <td>Tiến Hành xóa nhiều</td>
          <td>Mã sản phẩm</td>
          <td>Tên sản phẩm</td>
          <td>Gía sản phẩm</td>
          <td>% Khuyến mại</td>
          <td>Gía khuyến mại</td>
          <td>Khuyến mại theo giá</td>
          <td>Thương hiệu</td>
          <td>Nhóm sản phẩm</td>
          <td>Trạng thái</td>
        </tr>
        {data.map((item , id) => (
          <tr key={id}>
            <td>{++id}</td>
            <td><button onClick={e => onPresDetelRow(id)}>Xóa</button></td>
            <td><input type={"checkbox"} value={item.ProductCode} onChange={handleDelete} /></td>
            <td>{item.ProductCode}</td>
            <td>{item.ProductName}</td>
            <td>{item.Price}</td>
            <td>{item.UPRateDc}</td>
            <td>{item.UPDc}</td>
            <td>{item.FlagPrice}</td>
            <td>{item.BrandCode}</td>
            <td>{item.CateProCode}</td>
            <td>{item.FlagActive}</td>
            <td><button onClick={e => onPresEditingRow(item , id)}>Chỉnh sửa</button></td>
           
          </tr>
        ))
        }
      </table>
      <div>
        Id <input value={newid} disabled={edittingRow} onChange={onchangeNewID} />
      </div>
      <div>
        Thương Hiệu <input onChange={onchangeThuonghieu} />
      </div>
      <div>
        Nhóm sản phẩm <input onChange={onchangeSanpham} />
      </div>
      <div>
        Mã sản phẩm<input onChange={onchangeMasp} />
      </div>
      <div>
        Tên sản phẩm <input onChange={onchangeTensp} />
      </div>
      <div>
        Gía<input onChange={onchangeGia} />
      </div><div>
        Trạng thái<input onChange={onchangeTrangthai} />
      </div>
   
      {
        edittingRow
          ?
          <button onClick={handleChangeUpdate}>sửa</button>
          :
          <button onClick={handleSumbit}>thêm</button>
      }

    </div>
  );
}
